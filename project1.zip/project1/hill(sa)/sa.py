import random
from random import shuffle
import copy
import math
import matplotlib.pyplot as plt

def hill_climbing(board):
    temp =500
    check_list=[]
    local_optimum_counter = 0
    up_steps_counter = 0
    board = random_board(board)
    while (threat_count(board)[0] != 0):
        moves = moves_to_childs(board)
        shuffle(moves)
        for move in moves:
            child = copy.deepcopy(board)
            for j in range(0, 8): 
                child[move[0]][j] = 0
            child[move[0]][move[1]] = 1  
            if temp != 1:
                temp -= 1
            if threat_count(child)[0] < threat_count(board)[0]:
                up_steps_counter = up_steps_counter + 1
                board = copy.deepcopy(child)
                break  
            else:
                check_list.append(math.exp(-1 * abs(10) / temp))
                if ((math.exp(-1 * abs(10) / temp)) * 100) > random.randint(0, 100):
                    pass
            if move == moves[-1]:  
                local_optimum_counter = local_optimum_counter + 1
                board = random_board(board)
    printSolution(board)

if __name__ == '__main__':
    board = [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]]
    start=time.time()

    hill_climbing(board)
    end = time.time()
    print('Time cost ' + str('%.4f' % (end-start)) + 's')