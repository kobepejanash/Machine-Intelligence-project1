import random
import time
import module
start = time.time()
frontier_queue = [[0] * 8] 
solution = []
flag = 0

while frontier_queue: 
    if flag == 1:
        break
    seqs = frontier_queue.pop(0) 
    nums = list(range(1, 9))  
    for j in range(8): 
        pos = seqs.index(0)
        temp_seqs = list(seqs)
        temp = random.choice(nums)  
        temp_seqs[pos] = temp 
        nums.remove(temp)  
        if attacked_queens_pairs(temp_seqs) == 0: 
            frontier_queue.append(temp_seqs)
            if 0 not in temp_seqs: 
                solution = temp_seqs
                flag = 1  
                break
if solution:
    display_board(solution)
else:
    print("No Solution")

end = time.time()
print('Time cost ' + str('%.4f' % (end-start)) + 's')


