import numpy as np

def attacked_queens_pairs(qs):
    a = np.array([0] * 81)  
    a = a.reshape(9, 9)  
    n = 0 
    for i in range(1, 9):
        if qs[i-1] != 0: 
            a[qs[i - 1]][i] = 1 

    for i in range(1, 9):
        if qs[i - 1] == 0:continue
        for k in list(range(1, i)) + list(range(i + 1, 9)):  
            if a[qs[i - 1]][k] == 1: 
                n += 1
        f1 = f2 = qs[i - 1]
        for j in range(i - 1, 0, -1): 
            if f1 != 1:
                f1 -= 1
                if a[f1][j] == 1:
                    n += 1  
            if f2 != 8:
                f2 += 1
                if a[f2][j] == 1:
                    n += 1  
        f1 = f2 = qs[i - 1]
        for j in range(i + 1, 9): 
            if f1 != 1:
                f1 -= 1
                if a[f1][j] == 1:
                    n += 1 

            if f2 != 8:
                f2 += 1
                if a[f2][j] == 1:
                    n += 1  
    return int(n/2)

def display_board(qs):

    board = np.array([0] * 81)  
    board = board.reshape(9, 9) 

    for i in range(1, 9):
        board[qs[i - 1]][i] = 1  
    #print('board:')
    for i in board[1:]:
        for j in i[1:]:
            print(j, ' ', end="")  
        print() 
    #print('attack' + str(attacked_queens_pairs(qs)))



