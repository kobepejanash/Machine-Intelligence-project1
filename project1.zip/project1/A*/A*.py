start = time.time()
frontier_priority_queue = [{'unplaced_queens':8, 'pairs':28, 'seqs':[0] * 8}] 
solution = []
flag = 0 

while frontier_priority_queue: 
    first = frontier_priority_queue.pop(0)  
    if first['pairs'] == 0 and first['unplaced_queens'] == 0: 
        solution = first['seqs']
        flag = 1  
        break
    nums = list(range(1, 9))  
    seqs = first['seqs']
    if seqs.count(0) == 0: 
        continue 
    for j in range(8): 
        pos = seqs.index(0)
        temp_seqs = list(seqs)
        temp = random.choice(nums)  
        temp_seqs[pos] = temp 
        nums.remove(temp) 
        frontier_priority_queue.append({'unplaced_queens':temp_seqs.count(0), 'pairs':attacked_queens_pairs(temp_seqs),'seqs':temp_seqs})
    frontier_priority_queue = sorted(frontier_priority_queue, key=lambda x:(x['pairs']+x['unplaced_queens']))
if solution:
    display_board(solution)
else:
    print("No Solution")

end = time.time()
print('Time cost ' + str('%.4f' % (end-start)) + 's')


