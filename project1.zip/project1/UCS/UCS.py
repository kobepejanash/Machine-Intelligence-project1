import random
import time
import module
start = time.time()
frontier_priority_queue = [{'placed_queens':0, 'seqs':[0] * 8}] 
solution = []
flag = 0 
while frontier_priority_queue: 
    first = frontier_priority_queue.pop(0) 
    seqs = first['seqs']
    if first['placed_queens'] == 8: 
        solution = seqs
        flag = 1 
        break
    nums = list(range(1, 9)) 
    pos = seqs.index(0)
    for j in range(8): 
        temp_seqs = list(seqs)
        temp = random.choice(nums)  
        temp_seqs[pos] = temp 
        nums.remove(temp)  
        if attacked_queens_pairs(temp_seqs) == 0:  
            frontier_priority_queue.append({'placed_queens':8-temp_seqs.count(0), 'seqs':temp_seqs}) 
    frontier_priority_queue = sorted(frontier_priority_queue, key=lambda x:x['placed_queens'], reverse=True) 

if solution:
    display_board(solution)
else:
    print("No Solution")

end = time.time()
print('Time cost ' + str('%.4f' % (end-start)) + 's')


