import time 
global N
N = 8
       
def safe(board, row, col):
    for i in range(col):
        if board[row][i] == 1:
            return False
    for i, j in zip(range(row, -1, -1), range(col, -1, -1)):
        if board[i][j] == 1:
            return False
    for i, j in zip(range(row, N, 1), range(col, -1, -1)):
        if board[i][j] == 1:
            return False
    return True

def prints(board):
    for i in range(N):
        for j in range(N):
            print (board[i][j],end=' ')
        print()
#@profile
def sol(board, col):
    if col >= N:
        return True
    for i in range(N):
        if safe(board, i, col):
            board[i][col] = 1
            if sol(board, col + 1) == True:
                return True
            board[i][col] = 0
    return False
 
def solnq():
    board = np.array([0] * 81)  
    board = board.reshape(9, 9)
    if sol(board, 0) == False:
        print ("No Solution")
        return False
    prints(board)
    return True

start = time.time()
solnq()
end = time.time()
print('Time cost ' + str('%.4f' % (end-start)) + 's')